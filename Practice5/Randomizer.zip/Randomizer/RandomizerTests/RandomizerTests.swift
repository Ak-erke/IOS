//
//  RandomizerTests.swift
//  RandomizerTests
//
//  Created by Ақерке Амиртай on 22.10.2025.
//

import Testing
@testable import Randomizer

struct RandomizerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
