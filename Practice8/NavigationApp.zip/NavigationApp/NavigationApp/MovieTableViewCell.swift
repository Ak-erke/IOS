//
//  MoviewTableViewCell.swift
//  TableViewApp
//
//  Created by Akerke Amirtay on 21.11.2025.
//

import UIKit

class MovieTableViewCell: UITableViewCell {
    
    @IBOutlet weak var movieCover: UIImageView!
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var movieDirector: UILabel!
    @IBOutlet weak var movieReview: UILabel!
    @IBOutlet weak var watchedButton: UIButton!
    
    private var isWatched: Bool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configure(movie: TableItem) {
        if(movie.category != Category.movie){
            return
        }
        movieTitle.text = movie.title
        movieDirector.text = movie.subtitle
        movieReview.text = movie.review
        movieCover.image = movie.image
        isWatched = movie.isWatched
        updateWatchedButton()
    }

    @IBAction func watchedButtonTapped(_ sender: UIButton) {
        isWatched.toggle()
        updateWatchedButton()
    }

    private func updateWatchedButton() {
        let imageName = isWatched ? "eye.fill" : "eye"
        watchedButton.setImage(UIImage(systemName: imageName), for: .normal)
    }

}
