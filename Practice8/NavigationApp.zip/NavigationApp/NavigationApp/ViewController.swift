//
//  ViewController.swift
//  NavigationApp
//
//  Created by Akerke Amirtay on 21.11.2025.
//

import UIKit

// Основной контроллер для отображения списка элементов в UITableView
// Реализует UITableViewDelegate и UITableViewDataSource
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - Outlets
    @IBOutlet private weak var table : UITableView! // UITableView для отображения списка элементов
    
    // MARK: - Properties
    // Массив элементов для отображения, должен переопределяться в дочерних контроллерах
    var items: [TableItem] { [] }
    
    // Выбранный элемент при клике на строку, передается в DetailViewController
    var selectedItem : TableItem?

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Устанавливаем источник данных и делегата для таблицы
        table.dataSource = self
        table.delegate = self
    }

    // MARK: - UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Возвращаем количество элементов в массиве
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Получаем ячейку для конкретной строки, вызывая метод getCell (переопределяется в дочерних контроллерах)
        return getCell(tableView: tableView, indexPath: indexPath)
    }
    
    // MARK: - UITableViewDelegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Сохраняем выбранный элемент
        selectedItem = getSelectedItem(indexPath: indexPath)
        
        // Выполняем переход на экран с деталями
        performSegue(withIdentifier: "showDetails", sender: self)
    }
    
    // MARK: - Methods to Override
    // Метод для получения и настройки ячейки (пустой в базовом контроллере, переопределяется в наследниках)
    func getCell(tableView: UITableView, indexPath : IndexPath) ->  UITableViewCell {
        return UITableViewCell()
    }
    
    // Метод для получения выбранного элемента (пустой в базовом контроллере, переопределяется в наследниках)
    func getSelectedItem(indexPath : IndexPath) -> TableItem? {
        return nil
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Передача выбранного элемента в DetailViewController перед переходом
        if segue.identifier == "showDetails",
           let destination = segue.destination as? DetailViewController {
            destination.item = selectedItem
        }
    }
}

// MARK: - Category Enum
// Категории элементов, которые могут отображаться в таблице
enum Category : String, CaseIterable {
    case movie = "Movie"
    case audio = "Audio"
    case book = "Book"
    case course = "Course"
}

// MARK: - TableItem Struct
// Модель данных для элементов таблицы
struct TableItem {
    let title: String       // Название элемента
    let subtitle: String    // Подзаголовок / имя автора или исполнителя
    let review: String      // Описание или отзыв
    let image: UIImage      // Изображение обложки
    let category : Category // Категория элемента
    var isWatched: Bool = false // Состояние "просмотрено"
    var rating: Int = 0         // Рейтинг элемента (1-5)
}

    
