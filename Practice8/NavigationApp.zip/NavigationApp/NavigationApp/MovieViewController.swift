//
//  ViewController.swift
//  NavigationApp
//
//  Created by Akerke Amirtay on 21.11.2025.
//

import UIKit

let movies: [TableItem] = [
    TableItem(title: "The Queen's Gambit",
              subtitle: "by Scott Frank",
              review: "A gripping drama series about a chess prodigy struggling with fame and personal challenges.",
              image: #imageLiteral(resourceName: "movie1"),
              category: .movie),
    
    TableItem(title: "Hachiko: A Dog's Story",
              subtitle: "by Lasse Hallström",
              review: "A touching true story of a dog's loyalty that brings tears to your eyes.",
              image: #imageLiteral(resourceName: "movie2"),
              category: .movie),
    
    TableItem(title: "Drive My Car",
              subtitle: "by Ryusuke Hamaguchi",
              review: "An emotional, slow-burn drama exploring grief, love, and human connection.",
              image: #imageLiteral(resourceName: "movie3"),
              category: .movie),
    
    TableItem(title: "Parasite",
              subtitle: "by Bong Joon-ho",
              review: "A masterful dark comedy and thriller highlighting social inequality in a gripping way.",
              image: #imageLiteral(resourceName: "movie4"),
              category: .movie),
    
    TableItem(title: "Your Name",
              subtitle: "by Makoto Shinkai",
              review: "A beautiful anime film about fate, love, and time, visually stunning and emotionally deep.",
              image: #imageLiteral(resourceName: "movie5"),
              category: .movie),
    
    TableItem(title: "Interstellar",
              subtitle: "by Christopher Nolan",
              review: "A visually stunning sci-fi epic exploring space, time, and human perseverance.",
              image: #imageLiteral(resourceName: "movie6"),
              category: .movie),
    
    TableItem(title: "Green Book",
              subtitle: "by Peter Farrelly",
              review: "An uplifting story about friendship and overcoming prejudice in 1960s America.",
              image: #imageLiteral(resourceName: "movie7"),
              category: .movie),
    
    TableItem(title: "Ikiru",
              subtitle: "by Akira Kurosawa",
              review: "A powerful and reflective film about a man seeking meaning in the final days of his life.",
              image: #imageLiteral(resourceName: "movie8"),
              category: .movie),
    
    TableItem(title: "Cruella",
              subtitle: "by Craig Gillespie",
              review: "A stylish origin story of the iconic villain from 101 Dalmatians, full of fashion and mischief.",
              image: #imageLiteral(resourceName: "movie9"),
              category: .movie),
    
    TableItem(title: "Avatar: The Way of Water",
              subtitle: "by James Cameron",
              review: "The long-awaited sequel to Avatar, showcasing breathtaking underwater visuals and adventure.",
              image: #imageLiteral(resourceName: "movie10"),
              category: .movie)
]

class MovieViewController: ViewController {

    override var items: [TableItem] {
            return movies
    }
    
    override func getCell(tableView: UITableView, indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "movieCell") as! MovieTableViewCell
        let currentMovie = movies[indexPath.row]
        cell.configure(movie: currentMovie)
        return cell
    }
    
    override func getSelectedItem(indexPath: IndexPath) -> TableItem? {
        return movies[indexPath.row]
    }
}

