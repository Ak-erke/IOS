//
//  DetailViewController.swift
//  NavigationApp
//
//  Created by Akerke Amirtay on 21.11.2025.
//

import UIKit

// Контроллер для отображения детальной информации о выбранном элементе (например, аудио, видео, курс)
class DetailViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var coverImage: UIImageView! // Обложка элемента
    @IBOutlet weak var subTitle: UILabel!       // Подзаголовок / имя исполнителя
    @IBOutlet weak var mainTitle: UILabel!      // Основной заголовок / название трека
    @IBOutlet weak var reviewDescription: UILabel! // Текст обзора / описание

    // Кнопки рейтинга в виде звезд (от 1 до 5)
    @IBOutlet weak var star1Button: UIButton!
    @IBOutlet weak var star2Button: UIButton!
    @IBOutlet weak var star3Button: UIButton!
    @IBOutlet weak var star4Button: UIButton!
    @IBOutlet weak var star5Button: UIButton!

    // MARK: - Properties
    var item: TableItem?   // Текущий выбранный элемент для отображения
    var rating: Int = 0    // Текущий рейтинг (1-5), который отображается звездочками

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Если элемент передан, настраиваем UI с его данными
        if let item = item {
            configureInfo(item: item)
        }
        
        // Обновляем звездочки на основе текущего рейтинга
        updateStars()
    }

    // MARK: - Configure UI
    func configureInfo(item: TableItem){
        // Устанавливаем текст и изображение
        mainTitle.text = item.title         // Название
        subTitle.text = item.subtitle      // Подзаголовок / артист
        reviewDescription.text = item.review // Описание / отзыв
        coverImage.image = item.image       // Картинка обложки
        
        // Устанавливаем текущий рейтинг, если он есть в модели
        rating = item.rating // Необходимо добавить поле rating в модель TableItem
    }

    // MARK: - Actions
    @IBAction func starButtonTapped(_ sender: UIButton) {
        // Определяем, какая звезда была нажата, и обновляем рейтинг
        switch sender {
        case star1Button: rating = 1
        case star2Button: rating = 2
        case star3Button: rating = 3
        case star4Button: rating = 4
        case star5Button: rating = 5
        default: break
        }
        
        // После изменения рейтинга обновляем отображение звездочек
        updateStars()
    }

    // MARK: - Update Stars
    func updateStars() {
        // Массив кнопок для упрощения перебора
        let stars = [star1Button, star2Button, star3Button, star4Button, star5Button]
        
        for (index, button) in stars.enumerated() {
            guard let button = button else { continue } // Пропускаем, если кнопка nil
            
            // Если индекс кнопки меньше рейтинга, отображаем заполненную звезду, иначе пустую
            let imageName = index < rating ? "star.fill" : "star"
            button.setImage(UIImage(systemName: imageName), for: .normal)
        }
    }
}
