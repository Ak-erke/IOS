//
//  ViewController.swift
//  NavigationApp
//
//  Created by Akerke Amirtay on 21.11.2025.
//

import UIKit

// Массив аудио-элементов, которые будут отображаться в таблице
let audios: [TableItem] = [
    TableItem(title: "Gabriela", subtitle: "Katseye", review: "Solo album by Katseye, showcasing her unique style and personal musical exploration.", image: #imageLiteral(resourceName: "track1"), category: .audio),
    TableItem(title: "Blinding Lights", subtitle: "The Weeknd", review: "Hit album featuring The Weeknd’s signature synth-pop and smooth vocals.", image: #imageLiteral(resourceName: "track2"), category: .audio),
    TableItem(title: "Like Jennie", subtitle: "Jennie", review: "Energetic solo track by Jennie, highlighting her charisma and performance skills.", image: #imageLiteral(resourceName: "track3"), category: .audio),
    TableItem(title: "Starboy", subtitle: "The Weeknd", review: "A chart-topping album exploring fame, love, and personal struggles with a modern R&B touch.", image: #imageLiteral(resourceName: "track4"), category: .audio),
    TableItem(title: "Call Out My Name", subtitle: "The Weeknd", review: "Emotional R&B track with soulful vocals and heartfelt lyrics.", image: #imageLiteral(resourceName: "track5"), category: .audio),
    TableItem(title: "Қозы көрпеш - Баян сұлу", subtitle: "Bonapart x Merey", review: "A powerful collaboration blending Kazakh traditional motifs with modern pop elements.", image: #imageLiteral(resourceName: "track6"), category: .audio),
    TableItem(title: "Bipl", subtitle: "Yenlik", review: "Iconic album filled with strong vocals, R&B-pop hits, and empowering themes.", image: #imageLiteral(resourceName: "track7"), category: .audio),
    TableItem(title: "911", subtitle: "Acxa Prince", review: "Raw and expressive rap album showcasing Acxa Prince’s signature rebellious style.", image: #imageLiteral(resourceName: "track8"), category: .audio),
    TableItem(title: "Sulu", subtitle: "Alpha", review: "Creative mix of hip-hop and storytelling, featuring sharp lyrics and emotional depth.", image: #imageLiteral(resourceName: "track9"), category: .audio),
    TableItem(title: "Black Swan", subtitle: "BTS", review: "A dynamic track with powerful vocals and emotional storytelling, blending pop and hip-hop elements.", image: #imageLiteral(resourceName: "track10"), category: .audio)
]

// Контроллер для отображения аудио-контента в таблице
class AudioViewController: ViewController {

    // Переопределяем items, чтобы вернуть только аудио-данные
    override var items: [TableItem] {
        return audios
    }
    
    // Метод для получения и настройки ячейки таблицы
    override func getCell(tableView: UITableView, indexPath: IndexPath) -> UITableViewCell {
        // Декьюируем ячейку с идентификатором "audioCell" и приводим к нашему типу AudioTableViewCell
        let cell = tableView.dequeueReusableCell(withIdentifier: "audioCell") as! AudioTableViewCell
        
        // Получаем текущий аудио-объект для строки
        let currentAudio = audios[indexPath.row]
        
        // Настраиваем ячейку с данными аудио
        cell.configure(audio: currentAudio)
        
        return cell
    }
    
    // Метод для получения выбранного элемента при клике на строку
    override func getSelectedItem(indexPath: IndexPath) -> TableItem? {
        return audios[indexPath.row]
    }
}


