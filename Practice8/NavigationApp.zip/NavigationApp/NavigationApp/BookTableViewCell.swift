//
//  BookTableViewCell.swift
//  TableViewApp
//
//  Created by Akerke Amirtay on 21.11.2025.
//

import UIKit

class BookTableViewCell: UITableViewCell {
    @IBOutlet weak var bookCover: UIImageView!
    @IBOutlet weak var bookAuthor: UILabel!
    @IBOutlet weak var bookTitle: UILabel!
    @IBOutlet weak var bookReview: UILabel!
    @IBOutlet weak var watchedButton: UIButton!
    
    private var isWatched: Bool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configure(book: TableItem) {
        if(book.category != Category.book){
            return
        }
        bookTitle.text = book.title
        bookAuthor.text = book.subtitle
        bookReview.text = book.review
        bookCover.image = book.image
        isWatched = book.isWatched
        updateWatchedButton()
    }
    
    @IBAction func watchedButtonTapped(_ sender: UIButton) {
        isWatched.toggle()
        updateWatchedButton()
    }

    private func updateWatchedButton() {
        let imageName = isWatched ? "eye.fill" : "eye"
        watchedButton.setImage(UIImage(systemName: imageName), for: .normal)
    }

}
