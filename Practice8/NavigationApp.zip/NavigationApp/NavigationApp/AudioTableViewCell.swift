//
//  AudioTableViewCell.swift
//  TableViewApp
//
//  Created by Akerke Amirtay on 21.11.2025.
//

import UIKit

// Класс ячейки таблицы для отображения аудио-элемента
class AudioTableViewCell: UITableViewCell {
    // Обложка аудиозаписи
    @IBOutlet weak var audioCover: UIImageView!
    // Название аудио
    @IBOutlet weak var audioName: UILabel!
    // Текст обзора / отзыв
    @IBOutlet weak var review: UILabel!
    // Имя исполнителя
    @IBOutlet weak var artistLabel: UILabel!
    // Кнопка "просмотрено"
    @IBOutlet weak var watchedButton: UIButton!
    
    // Локальное состояние: было ли аудио помечено как просмотренное
    private var isWatched: Bool = false
    
    // Вызывается после загрузки ячейки из .xib или storyboard
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    // Настройка данных для отображения в ячейке
    func configure(audio: TableItem) {
        // Проверяем категорию, чтобы ячейка не получила неподходящий тип данных
        if(audio.category != Category.audio){
            return
        }
        
        // Установка текстов и изображения
        audioName.text = audio.title
        artistLabel.text = audio.subtitle
        review.text = audio.review
        audioCover.image = audio.image
        
        // Получаем состояние "просмотрено" из модели
        isWatched = audio.isWatched
        
        // Обновляем отображение кнопки
        updateWatchedButton()
    }
    
    // Срабатывает при нажатии кнопки "просмотрено"
    @IBAction func watchedButtonTapped(_ sender: UIButton) {
        // Переключаем состояние
        isWatched.toggle()
        
        // Обновляем иконку кнопки
        updateWatchedButton()
    }

    // Обновляет изображение кнопки в зависимости от состояния
    private func updateWatchedButton() {
        // Выбираем иконку: заполненный глаз — просмотрено, обычный — нет
        let imageName = isWatched ? "eye.fill" : "eye"
        
        // Устанавливаем системную иконку
        watchedButton.setImage(UIImage(systemName: imageName), for: .normal)
    }
}
