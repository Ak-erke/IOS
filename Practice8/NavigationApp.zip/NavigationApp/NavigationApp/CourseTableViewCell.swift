//
//  CourseTableViewCell.swift
//  TableViewApp
//
//  Created by Akerke Amirtay on 21.11.2025.
//

import UIKit

class CourseTableViewCell: UITableViewCell {
    @IBOutlet weak var courseCover: UIImageView!
    @IBOutlet weak var courseTitle: UILabel!
    @IBOutlet weak var courseLecturer: UILabel!
    @IBOutlet weak var courseReview: UILabel!
    @IBOutlet weak var watchedButton: UIButton!
    
    private var isWatched: Bool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configure(course: TableItem) {
        if(course.category != Category.course){
            return
        }
        courseTitle.text = course.title
        courseLecturer.text = course.subtitle
        courseReview.text = course.review
        courseCover.image = course.image
        isWatched = course.isWatched
        updateWatchedButton()
    }
    
    @IBAction func watchedButtonTapped(_ sender: UIButton) {
        isWatched.toggle()
        updateWatchedButton()
    }

    private func updateWatchedButton() {
        let imageName = isWatched ? "eye.fill" : "eye"
        watchedButton.setImage(UIImage(systemName: imageName), for: .normal)
    }


}
