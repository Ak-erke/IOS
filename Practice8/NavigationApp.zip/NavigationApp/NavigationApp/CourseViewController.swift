//
//  ViewController.swift
//  NavigationApp
//
//  Created by Akerke Amirtay on 21.11.2025.
//

import UIKit


let courses: [TableItem] = [
    TableItem(title: "iOS Development",
              subtitle: "Arman Myrzakanurov",
              review: "Учиться у Армана — сплошное удовольствие! Сразу хочется писать крутые приложения на Swift.",
              image: #imageLiteral(resourceName: "course1"),
              category: .course),
    
    TableItem(title: "Web Development",
              subtitle: "Arman Myrzakanurov",
              review: "Легко и понятно! От верстки до интерактивных сайтов — всё объясняется на практике.",
              image: #imageLiteral(resourceName: "course2"),
              category: .course),
    
    TableItem(title: "Power BI",
              subtitle: "Dilyara Akhmatova",
              review: "Простые объяснения и много практики — после курса хочется строить отчёты как профи.",
              image: #imageLiteral(resourceName: "course3"),
              category: .course),
    
    TableItem(title: "PE",
              subtitle: "Yuri Krutin",
              review: "Весело и активно! Заряд энергии на весь день и полезные упражнения для здоровья.",
              image: #imageLiteral(resourceName: "course4"),
              category: .course),
    
    TableItem(title: "SQL",
              subtitle: "Dilyara Akhmatova",
              review: "Все тонкости работы с базами данных подаются доступно, хочется сразу писать запросы.",
              image: #imageLiteral(resourceName: "course5"),
              category: .course),
    
    TableItem(title: "History of Kazakhstan",
              subtitle: "Arman Jumadil",
              review: "История Казахстана оживает! Повествование захватывает с древности до современности.",
              image: #imageLiteral(resourceName: "course6"),
              category: .course),
    
    TableItem(title: "PP2",
              subtitle: "Arnur Kelgenbayev",
              review: "Проекты и практика каждый урок! Учишься думать как настоящий программист.",
              image: #imageLiteral(resourceName: "course7"),
              category: .course),
    
    TableItem(title: "Algorithm",
              subtitle: "Nurmukhan Kaster",
              review: "Алгоритмы становятся понятными и даже увлекательными, а задачи мотивируют решать больше.",
              image: #imageLiteral(resourceName: "course8"),
              category: .course),
    
    TableItem(title: "Character Design",
              subtitle: "Yulya Sutchenko",
              review: "Креативный взрыв! Учишься делать персонажей живыми и запоминающимися.",
              image: #imageLiteral(resourceName: "course9"),
              category: .course),
    
    TableItem(title: "Filmmaking",
              subtitle: "Yuliiya Sutchenko",
              review: "От идеи до экрана — весь процесс съемки раскрывается полностью. Хочется снимать сразу!",
              image: #imageLiteral(resourceName: "course10"),
              category: .course)
]




class CourseViewController: ViewController {

    override var items: [TableItem] {
            return courses
    }
    
    override func getCell(tableView: UITableView, indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "courseCell") as! CourseTableViewCell
        let currentCourse = courses[indexPath.row]
        cell.configure(course: currentCourse)
        return cell
    }
    
    override func getSelectedItem(indexPath: IndexPath) -> TableItem? {
        return courses[indexPath.row]
    }
}

