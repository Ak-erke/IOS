//
//  ViewController.swift
//  NavigationApp
//
//  Created by Akerke Amirtay on 21.11.2025.
//

import UIKit

let books: [TableItem] = [
    TableItem(title: "Оян, қазақ",
              subtitle: "М. Дулатов",
              review: "Классическое произведение казахской литературы, вдохновляющее на национальное пробуждение.",
              image: #imageLiteral(resourceName: "book1"),
              category: .book),
    
    TableItem(title: "Бақытсыз Жамал",
              subtitle: "М. Әуезов",
              review: "Трогательная и глубокая история о любви и социальной несправедливости.",
              image: #imageLiteral(resourceName: "book2"),
              category: .book),
    
    TableItem(title: "Маленькие женщины",
              subtitle: "Луиза Мэй Олкотт",
              review: "Любимая классика о семье, взрослении и женской силе.",
              image: #imageLiteral(resourceName: "book3"),
              category: .book),
    
    TableItem(title: "Менің атым — Қожа",
              subtitle: "Г. Мустафин",
              review: "Интересная история о детстве, приключениях и взрослении.",
              image: #imageLiteral(resourceName: "book4"),
              category: .book),
    
    TableItem(title: "Конаев естелік эссе",
              subtitle: "Д. Конаев",
              review: "Познавательные и вдохновляющие эссе о жизни и истории Казахстана.",
              image: #imageLiteral(resourceName: "book5"),
              category: .book),
    
    TableItem(title: "Война и мир",
              subtitle: "Лев Толстой",
              review: "Эпический роман о любви, судьбе и исторических событиях России начала XIX века.",
              image: #imageLiteral(resourceName: "book6"),
              category: .book),
    
    TableItem(title: "И дольше века длится день",
              subtitle: "Чингиз Айтматов",
              review: "Сильный роман о человеке, истории и культуре Кыргызстана, переплетение реализма и фольклора.",
              image: #imageLiteral(resourceName: "book7"),
              category: .book),
    
    TableItem(title: "Мастер и Маргарита",
              subtitle: "Михаил Булгаков",
              review: "Сатирический и мистический роман о добре и зле, любви и власти в Москве 30-х годов.",
              image: #imageLiteral(resourceName: "book8"),
              category: .book),
    
    TableItem(title: "Преступление и наказание",
              subtitle: "Фёдор Достоевский",
              review: "Философский роман о моральных дилеммах, искуплении и человеческой психологии.",
              image: #imageLiteral(resourceName: "book9"),
              category: .book),
    
    TableItem(title: "Тихий Дон",
              subtitle: "Михаил Шолохов",
              review: "Эпическая сага о любви, войне и жизни казаков на фоне революции и гражданской войны.",
              image: #imageLiteral(resourceName: "book10"),
              category: .book)
]


class BookViewController: ViewController {

    override var items: [TableItem] {
            return books
    }
    
    override func getCell(tableView: UITableView, indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "bookCell") as! BookTableViewCell
        let currentBook = books[indexPath.row]
        cell.configure(book: currentBook)
        return cell
    }
    
    override func getSelectedItem(indexPath: IndexPath) -> TableItem? {
        return books[indexPath.row]
    }
}

