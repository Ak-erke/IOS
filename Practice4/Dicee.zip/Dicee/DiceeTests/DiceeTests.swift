//
//  DiceeTests.swift
//  DiceeTests
//
//  Created by Ақерке Амиртай on 17.10.2025.
//

import Testing
@testable import Dicee

struct DiceeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
